# eefAnalytics 1.1.1

* Added a `NEWS.md` file to track changes to the package.
