utils::globalVariables(c("intervention","Index","ES","LB.95","UB.95","Variance","Anot","Xaxis","Name"))
